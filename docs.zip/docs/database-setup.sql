CREATE TABLE users (
	id int NOT NULL IDENTITY(1,1),
	first_name varchar(20),
	last_name varchar(30),
	email varchar(40),
	phone varchar(15),
	pass varchar(30),
	admin_access bit,
	mgr_access bit
)

INSERT INTO users (first_name, last_name, email, admin_access)
VALUES
('John', 'Fritter', 'j_fritter@mail.fhsu.edu', 1),
('Panharith', 'Menh', 'p_menh@mail.fhsu.edu', 1),
('Omar', 'Omer', 'o_omer@mail.fhsu.edu', 1),
('Heather', 'Young', 'hjyoung@mail.fhsu.edu', 1)

CREATE TABLE dining_capacity (
	table_id int PRIMARY KEY NOT NULL IDENTITY(1, 1),
	max_seat_count int,
)

CREATE TABLE dining_reservations (
	id int NOT NULL IDENTITY(1,1),
	table_id int FOREIGN KEY REFERENCES dining_capacity(table_id),
	first_name varchar(20),
	last_name varchar(30),
	email varchar(40),
	phone varchar(15),
	res_time smalldatetime,
	duration time
)

CREATE TABLE special_events (
	id int PRIMARY KEY NOT NULL IDENTITY(1, 1),
	capacity int,
	contact_name varchar(30),
	contact_email varchar(40),
	contact_phone varchar(15),
	event_location varchar(30),
	title varchar(30),
	descript varchar(200),
	start_time smalldatetime,
	end_time smalldatetime
)

CREATE TABLE event_reservations (
	id int NOT NULL IDENTITY(1,1),
	first_name varchar(20),
	last_name varchar(30),
	email varchar(40),
	phone varchar(15),
	event varchar(30),
	res_time smalldatetime
)

CREATE TABLE spa_services (
	id int PRIMARY KEY NOT NULL IDENTITY(1, 1),
	title varchar(30),
	descript varchar(200)
)

CREATE TABLE therapists (
	id int PRIMARY KEY NOT NULL IDENTITY(1, 1),
	first_name varchar(20),
	last_name varchar(30),
	email varchar(40),
	phone varchar(15)
)

CREATE TABLE therapist_skills (
	therapist_id int FOREIGN KEY REFERENCES therapists(id),
	servic_id int FOREIGN KEY REFERENCES spa_services(id)
)

CREATE TABLE spa_reservations (
	id int NOT NULL IDENTITY(1,1),
	therapist_id int FOREIGN KEY REFERENCES therapists(id),
	client_name varchar(30),
	client_email varchar(40),
	client_phone varchar(15),
	spa_service varchar(30),
	res_time smalldatetime,
	duration time
)
INSERT INTO spa_services (title, descript)
VALUES
('Hot Stone Massage', '...'),
('Sport Massage', '...'),
('Swedish Massage', '...'),
('Reflexology', '...'),
('Facial', '...'),
('Manicure', '...'),
('Pedicure', '...')

INSERT INTO special_events (title, capacity, contact_name, contact_email, contact_phone, event_location, descript, start_time, end_time)
VALUES
('La Scala Opera Trip', 40, 'Andy Cohen', 'andy1@mail.com', '555-123-4567', 'Opera House', 'An evening at the La Scala Opera House.', '2023-10-20 19:30:00', '2023-10-20 23:00:00'),
('Night Club Hop', 16, 'Joe Jackson', 'joe1@mail.com', '555-987-6543', 'Various Nightclubs', 'A night of dancing and fun at the hottest nightclubs in town.', '2023-10-25 21:00:00', '2023-10-26 02:00:00'),
('Wine Tasting Event', 36, 'Alice Johnson', 'alice1@mail.com', '555-123-7890', 'Vineyard Estates', 'Join us for an evening of wine tasting and delicious appetizers.', '2023-11-05 18:00:00', '2023-11-05 21:00:00'),
('Charity Gala', 156, 'Michael Smith', 'michael1@mail.com', '888-555-1234', 'Grand Ballroom', 'An elegant charity gala to support a good cause with live music and fine dining.', '2023-12-10 19:00:00', '2023-12-10 23:00:00'),
('Beach Bonfire Party', 40, 'Emily Davis', 'emily1@beachmail.com', '555-234-5678', 'Golden Beach', 'Join us for a night of fun around the bonfire on the beach.', '2023-11-15 19:00:00', '2023-11-15 23:00:00'),
('Poolside BBQ Bash', 60, 'David Wilson', 'david1@resortmail.com', '555-345-6789', 'Main Pool', 'A BBQ party by the pool with great food and music.', '2023-11-18 14:00:00', '2023-11-18 18:00:00'),
('Holiday Carnival', 80, 'Sarah Johnson', 'sarah1@celebrationmail.com', '555-456-7890', 'Resort Grounds', 'Get into the holiday spirit with games, rides, and delicious treats.', '2023-11-23 11:00:00', '2023-11-23 17:00:00'),
('Festive Luau', 50, 'Michael Smith', 'michael2@luau.com', '888-555-1234', 'Luau Pavilion', 'Celebrate the season with a Hawaiian-themed luau featuring traditional dances and cuisine.', '2023-12-05 18:30:00', '2023-12-05 22:30:00'),
('Holiday Movie Night', 30, 'Alice Johnson', 'alice2@holidaycinema.com', '555-987-6543', 'Resort Cinema', 'Enjoy classic holiday films under the stars with popcorn and hot cocoa.', '2023-12-20 20:00:00', '2023-12-20 23:00:00'),
('Snowy Ski Trip', 25, 'John Fritter', 'john1@snowyski.com', '555-234-5678', 'Mountain Lodge', 'Hit the slopes and enjoy a snowy adventure with skiing and cozy cabins.', '2023-12-28 09:00:00', '2023-12-29 16:00:00')

INSERT INTO dining_capacity (max_seat_count)
VALUES (4), (6), (2), (8), (4), (6), (2), (8), (4), (6), (2), (8), (4), (6), (2), (8), (4), (6), (2), (8);

UPDATE users
SET pass = CONCAT('password', id);

CREATE TABLE guests (
    id INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(40),
    last_name VARCHAR(40),
    email VARCHAR(40),
    password VARCHAR(40)
);

CREATE TABLE employees (
    id INT IDENTITY(1,1) PRIMARY KEY,
    first_name VARCHAR(40),
    last_name VARCHAR(40),
    email VARCHAR(40),
    password VARCHAR(40),
    is_admin BIT,
    is_manager BIT,
    dept VARCHAR(60) NULL
);


INSERT INTO guests (first_name, last_name, email, password)
VALUES
    ('John', 'Fritter', 'j_fritter@mail.fhsu.edu', 'password1'),
    ('Panharith', 'Menh', 'p_menh@mail.fhsu.edu', 'password2'),
    ('Omar', 'Omar', 'o_omar@mail.fhsu.edu', 'password3'),
    ('Heather', 'Young', 'hjyoung@mail.fhsu.edu', 'password4');

INSERT INTO employees (first_name, last_name, email, password, is_admin, is_manager, dept)
VALUES
    ('John', 'Fritter', 'j_fritter@mail.fhsu.edu', 'password1', 1, 0, NULL),
    ('Panharith', 'Menh', 'p_menh@mail.fhsu.edu', 'password2', 1, 0, NULL),
    ('Omar', 'Omer', 'o_omer@mail.fhsu.edu', 'password3', 1, 0, NULL),
    ('Heather', 'Young', 'hjyoung@mail.fhsu.edu', 'password4', 1, 0, NULL),
	('Mike', 'Mireku', 'm_mirekukwakye@fhsu.edu', 'password5', 1, 0, NULL);
